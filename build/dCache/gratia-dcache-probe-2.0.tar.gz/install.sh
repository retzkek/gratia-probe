#!/bin/sh

help()
{
  echo "install.sh [-d]"
  echo
  echo "-d, --dryrun"
  echo "     Print what will be done, but done run any commands."
  echo
  echo "This script installs the dCache gratia probe. Run this script from the directory"
  echo "within which it is located. You need python in your path to install the probe."     
  exit 0
}

while [ $# -ne 0 ]
do	
  # Default to shifting to next parameter
  shift_size=1		
  if [ $1 = "--help" -o $1 = "-h" ] 
  then
    help
  fi
  if [ $1 = "--dryrun" -o $1 = "-d" ] 
  then
    DRY_RUN=true
  fi
  shift $shift_size
done

if [ "$DRY_RUN" == "true" ] ; then
  logfile=/dev/null
  logerr=/dev/null
  echo "Dryrun - will print actions but not perform them"
  echo
  EVAL="echo"
  REDIRECT1=""
  REDIRECT2=""
  ESC=""
else
  logfile=`pwd`/vdt-install.log
  logerr=`pwd`/vdt-install.err
  if [ -e $logfile  ] ; then
    rm $logfile
  fi
  if [ -e $logerr  ] ; then
    rm $logerr
  fi
  EVAL="eval"
  REDIRECT1=">> \$logfile"
  REDIRECT2="2>> \$logerr >> \$logfile"
  ESC="\\"
fi

$EVAL echo "Installing Gratia dCache probe as \"dCache:`hostname -f`\"." | tee -a $logfile

if [ ! -d data ] ; then
$EVAL mkdir data
fi
if [ ! -d logs ] ; then
$EVAL mkdir logs
fi
if [ ! -d tmp ] ; then
$EVAL mkdir tmp
fi

if ! python  -c 'from psycopg2 import psycopg1 as psycopg' > /dev/null 2>&1; then
  $EVAL cd tmp
  $EVAL tar zxvf ../external/psycopg2-2.0.5.1.tar.gz $REDIRECT1
  $EVAL cd psycopg2-2.0.5.1
  $EVAL python setup.py install $REDIRECT2
  if [ -s $logerr  ] ; then
    $EVAL echo "Installation of python module psycopg2-2.0.5.1 failed." | tee -a $logerr
    exit 1
  else
    $EVAL echo "Installed python module psycopg2-2.0.5.1." | tee -a $logfile
  fi
  $EVAL cd ..
  $EVAL rm -rf psycopg2-2.0.5.1
  $EVAL cd ..
fi

if ! python  -c "import pkg_resources; pkg_resources.require('sqlalchemy>=0.3.8')" > /dev/null 2>&1; then
  $EVAL cd tmp
  $EVAL tar zxvf ../external/SQLAlchemy-0.3.8.tar.gz $REDIRECT1
  $EVAL cd SQLAlchemy-0.3.8
  $EVAL python setup.py install $REDIRECT2
  if [ -s $logerr  ] ; then
    $EVAL echo "Installation of python module SQLAlchemy-0.3.8 failed." | tee -a $logerr
    exit 1
  else
    $EVAL echo "Installed python module SQLAlchemy-0.3.8." | tee -a $logfile
  fi
  $EVAL cd ..
  $EVAL rm -rf SQLAlchemy-0.3.8
  $EVAL cd ..
fi

$EVAL echo "Configuring probe." | tee -a $logfile
$EVAL sed -e s/BILLING_HOST/`hostname -f`/ "<" ProbeConfig ">" ProbeConfig.tmp
if [[ -r ProbeConfig.tmp || "$DRY_RUN" == "true" ]] ; then
  $EVAL mv -f ProbeConfig.tmp ProbeConfig
else
  $EVAL echo "Could not modify ProbeConfig file" | tee -a $logerr
  exit 1
fi

$EVAL echo "Gratia dCache probe installed."
$EVAL echo "To start the Gratia dCache probe, run"
$EVAL echo "nohup python dCacheBillingAggregator.py $ESC&" 


exit 0
