# Copyright 2007 Cornell University, Ithaca, NY. All rights reserved.
#
# Author:  Gregory J. Sharp
# Version: $Id: dCacheBillingAggregator.py,v 1.6 2007/05/08 18:49:19 zalokar Exp $
#
# This is a Python program that reads the dCache billing database, aggregates
# any new content, and sends it to Gratia.

import os
import sys
import time
import logging
import traceback
import xml.dom.minidom
# Python profiler
import hotshot
import hotshot.stats
# The gratia probe code
import Gratia
# Local modules
from Alarm import Alarm
from DCacheAggregator import DCacheAggregator

import signal


ProgramName = "dCacheBillingAggregator"


class dCacheProbeConfig( Gratia.ProbeConfiguration ):
    """
    This class extends the gratia ProbeConfiguration class so that we can
    add our own configuration parameters to the ProbeConfig file.
    The additional supported variables each have their own get_ function below.
    """
    _emailList = [ 'notdefined' ]
    def __init__( self ):
        # Just call the parent class to read in the file.
	# We just add some extra name/value readouts.
	Gratia.ProbeConfiguration.__init__( self )

    def getConfigAttribute( self, name ):
	return Gratia.ProbeConfiguration._ProbeConfiguration__getConfigAttribute( self, name )

    def get_UpdateFrequency( self ):
        return self.getConfigAttribute( 'UpdateFrequency' )

    def get_StopFileName( self ):
        return self.getConfigAttribute( 'StopFileName' )

    def get_DBHostName( self ):
        return self.getConfigAttribute( 'DBHostName' )

    def get_DBLoginName( self ):
        return self.getConfigAttribute( 'DBLoginName' )

    def get_DBPassword( self ):
        return self.getConfigAttribute( 'DBPassword' )

    def get_DCacheServerHost( self ):
        return self.getConfigAttribute( 'DCacheServerHost' )

    # This is the name of a host that is running an SMTP server to which
    # email messages can be submitted.
    def get_EmailServerHost( self ):
        return self.getConfigAttribute( 'EmailServerHost' )

    # This is the email address from which the email allegedly originated.
    # Some email servers will tweak it if they don't like it, rather than
    # rejecting it. Caveat emptor.
    def get_EmailFromAddress( self ):
        return self.getConfigAttribute( 'EmailFromAddress' )

    # This is the list of recipients for emails about pressing problems
    # encountered by the dCache probe. We save the list for subsequent
    # calls, since multiple alarms may be set up.
    def get_EmailToList( self ):
	if self._emailList[0] == 'notdefined':
	    value = self.getConfigAttribute( 'EmailToList' )
	    if value == '':
		print "WARNING: EmailToList is empty. Will use stdout."
	    self._emailList = value.split( ", " )
	return self._emailList

    # The logging level for this program is distinct from the logging
    # level for Gratia. We default to DEBUG if we don't recognize the
    # log level as "error", "warn" or "info"
    def get_AggrLogLevel( self ):
        level = self.getConfigAttribute( 'AggrLogLevel' )
	if level == "error":
	    return logging.ERROR
	elif level == "warn":
	    return logging.WARN
	elif level == "info":
	    return logging.INFO
	else:
	    return logging.DEBUG

# end class dCacheProbeConfig


if __name__ == '__main__':
    # We need the logger variable in the exception handler.
    # So we create it here.
    logger = logging.getLogger( 'DCacheAggregator' )

    # Ignore hangup signals. We shouldn't die just because our parent
    # shell logs out.
    signal.signal( signal.SIGHUP, signal.SIG_IGN )

    try:
	# Initialize gratia before attempting to read its config file.
	Gratia.Initialize()
	# Extract the configuration information into local variables.
        myconf = dCacheProbeConfig()

	# Get the name of the directory where we are to store the log files.
	logDir = myconf.get_LogFolder()
	logFileName = os.path.join( logDir, "dcache2gratia.log" )

	# Set up an alarm to send an email if the program terminates.
	termSubject = "dCache2Gratia probe is going down"
	termMessage = "The dCache probe for Gratia has terminated.\n" + \
		      "Please check the logfile\n\n   " + \
		      logFileName + \
		      "\n\nfor the cause.\n"

	terminationAlarm = Alarm( myconf.get_EmailServerHost(),
				  myconf.get_EmailFromAddress(),
				  myconf.get_EmailToList(),
				  termSubject, termMessage, 0, 0, False )

	# Make sure that the logging directory is present
	if not os.path.isdir( logDir ):
	    os.mkdir( logDir, 0755 )

	if os.path.exists( logFileName ):
	    backupName = logFileName + time.strftime("_%Y%m%d_%H%M%S")
	    os.rename( logFileName, backupName )

	# Set up the logger with a suitable format
	hdlr = logging.FileHandler( logFileName, 'w' )
	formatter = logging.Formatter( '%(asctime)s %(levelname)s %(message)s' )
	hdlr.setFormatter( formatter )
	logger.addHandler( hdlr )
	logger.setLevel( myconf.get_AggrLogLevel() )
	logger.info( "starting " + ProgramName )

	stopFileName = myconf.get_StopFileName()
	updateFreq = float( myconf.get_UpdateFrequency() )

	# Create the aggregator instance that we will use.
	aggregator = DCacheAggregator( myconf, logDir )

	# If profiling was requested, turn it on.
	profiling = sys.argv.count('-profile') > 0
	if profiling:
	    profiler = hotshot.Profile("profile.dat")
	    logger.info( "Enabling Profiling" )

	# Now aggregate new records, then sleep, until somebody creates
	# the stop file...
	while 1:
	    if profiling:
		profiler.run("aggregator.sendBillingInfoRecordsToGratia()")
	    else:
		aggregator.sendBillingInfoRecordsToGratia()
            # Are we are shutting down?
            if os.path.exists( stopFileName ):
                break
            time.sleep( updateFreq )

	# If we are profiling, print the results...
	if profiling:
	    profiler.close()
	    stats = hotshot.stats.load("profile.dat")
	    stats.sort_stats('time', 'calls')
	    stats.print_stats()

	logger.warn( ProgramName + " stop file detected." )
    except:
	# format the traceback into a string
        tblist = traceback.format_exception( sys.exc_type,
					     sys.exc_value,
					     sys.exc_traceback )
	msg = ProgramName + " caught an exception:\n" + "".join( tblist )
	logger.error( msg )
    # shut down the logger to make sure nothing is lost.
    logger.critical( ProgramName + " shutting down." )
    logging.shutdown()
    # try to send an email warning of the shutdown.
    terminationAlarm.event()
    sys.exit( 1 )

